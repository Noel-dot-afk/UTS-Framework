<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
{
    Schema::create('books', function (Blueprint $table) {
        $table->id(); 
        $table->foreignId('category_id')->constrained('categories')->onDelete('restrict'); 
        $table->string('title', 255); 
        $table->string('author', 100); 
        $table->integer('published_year'); 
        $table->integer('stock'); 
        $table->timestamps(); 
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('books');
    }
};
