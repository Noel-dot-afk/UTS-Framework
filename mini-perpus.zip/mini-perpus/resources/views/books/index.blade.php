@extends('layouts.app')

@section('content')
<div class="card shadow-sm">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="card-title fw-bold text-secondary m-0"><i class="bi bi-journal-text me-2"></i>Daftar Buku</h3>
            <a href="{{ route('books.create') }}" class="btn btn-primary shadow-sm">
                <i class="bi bi-plus-circle me-1"></i> Tambah Buku
            </a>
        </div>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <div class="table-responsive">
            <table class="table table-hover align-middle mt-2">
                <thead class="table-light">
                    <tr>
                        <th class="text-center text-secondary">ID</th>
                        <th class="text-secondary">Judul Buku</th>
                        <th class="text-secondary">Kategori</th>
                        <th class="text-secondary">Penulis</th>
                        <th class="text-secondary">Tahun</th>
                        <th class="text-secondary">Stok</th>
                        <th class="text-center text-secondary">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($books as $book)
                    <tr>
                        <td class="text-center fw-bold text-muted">{{ $book->id }}</td>
                        <td class="fw-semibold text-primary">{{ $book->title }}</td>
                        <!-- Tampilan Kategori menggunakan Badge[cite: 4, 6] -->
                        <td><span class="badge bg-info text-dark px-3 py-2 rounded-pill">{{ $book->category->name ?? 'Tidak ada' }}</span></td>
                        <td>{{ $book->author }}</td>
                        <td>{{ $book->published_year }}</td>
                        <td>
                            <!-- Warna Badge stok dinamis (Merah jika stok < 5, Hijau jika cukup) -->
                            <span class="badge {{ $book->stock < 5 ? 'bg-danger' : 'bg-success' }} px-3 py-2 rounded-pill">
                                {{ $book->stock }} Item
                            </span>
                        </td>
                        <td class="text-center">
                            <a href="{{ route('books.edit', $book->id) }}" class="btn btn-sm btn-warning text-dark shadow-sm">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <form action="{{ route('books.destroy', $book->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus buku ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger shadow-sm">
                                    <i class="bi bi-trash"></i> Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection