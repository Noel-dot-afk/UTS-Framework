

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="card-title fw-bold text-secondary m-0"><i class="bi bi-tags me-2"></i>Daftar Kategori</h3>
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary shadow-sm">
                <i class="bi bi-plus-circle me-1"></i> Tambah Kategori
            </a>
        </div>

        <!-- Menampilkan pesan sukses atau error constraint jika berelasi dengan buku[cite: 4, 6] -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle mt-2">
                <thead class="table-light">
                    <tr>
                        <th class="text-center text-secondary">ID</th>
                        <th class="text-secondary">Nama Kategori</th>
                        <th class="text-secondary">Deskripsi</th>
                        <th class="text-center text-secondary">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center fw-bold text-muted"><?php echo e($category->id); ?></td>
                        <td class="fw-semibold text-primary"><?php echo e($category->name); ?></td>
                        <td class="text-muted"><?php echo e($category->description ?? '-'); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-sm btn-warning text-dark shadow-sm">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus kategori ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger shadow-sm">
                                    <i class="bi bi-trash"></i> Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Noel\mini-perpus\resources\views/categories/index.blade.php ENDPATH**/ ?>