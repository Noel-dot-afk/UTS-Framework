<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return view('categories.index', compact('categories'));
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(Request $request)
    {
        // Validasi server-side wajib dilakukan di Controller[cite: 6]
        $request->validate([
            'name' => 'required|unique:categories,name', 
            'description' => 'nullable'
        ]);

        Category::create($request->all());
        return redirect()->route('categories.index')->with('success', 'Kategori berhasil ditambahkan!');
    }

    // Fungsi edit yang sebelumnya tidak ditemukan
    public function edit(Category $category)
    {
        return view('categories.edit', compact('category'));
    }

    public function update(Request $request, Category $category)
    {
        // Validasi saat update, mengecualikan nama yang sedang diedit
        $request->validate([
            'name' => 'required|unique:categories,name,' . $category->id,
            'description' => 'nullable'
        ]);

        $category->update($request->all());
        return redirect()->route('categories.index')->with('success', 'Kategori berhasil diperbarui!');
    }

    public function destroy(Category $category)
    {
        // Menangani constraint/error jika kategori masih memiliki relasi ke buku[cite: 4]
        if ($category->books()->count() > 0) {
            return redirect()->route('categories.index')->with('error', 'Gagal: Kategori masih memiliki relasi ke buku!');
        }

        $category->delete();
        return redirect()->route('categories.index')->with('success', 'Kategori berhasil dihapus!');
    }
}