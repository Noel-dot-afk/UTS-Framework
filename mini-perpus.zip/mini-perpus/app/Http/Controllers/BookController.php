<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function index()
    {
        // Mengambil semua data buku beserta relasi kategorinya (Eager Loading)
        $books = Book::with('category')->get();
        return view('books.index', compact('books'));
    }

    public function create()
    {
        // Menarik data kategori secara dinamis dari database untuk dropdown
        $categories = Category::all();
        return view('books.create', compact('categories'));
    }

    public function store(Request $request)
    {
        // Validasi form mutlak di Controller[cite: 6]
        $request->validate([
            'title' => 'required|max:255', // Aturan minimum UTS[cite: 6]
            'category_id' => 'required|exists:categories,id',
            'author' => 'required|string|max:100',
            'published_year' => 'required|numeric', // Aturan minimum UTS[cite: 6]
            'stock' => 'required|integer|min:0'
        ]);

        Book::create($request->all());
        return redirect()->route('books.index')->with('success', 'Buku berhasil ditambahkan!');
    }

    public function edit(Book $book)
    {
        // Mengirim data buku yang sedang diedit dan semua pilihan kategori
        $categories = Category::all();
        return view('books.edit', compact('book', 'categories'));
    }

    public function update(Request $request, Book $book)
    {
        $request->validate([
            'title' => 'required|max:255',
            'category_id' => 'required|exists:categories,id',
            'author' => 'required|string|max:100',
            'published_year' => 'required|numeric',
            'stock' => 'required|integer|min:0'
        ]);

        $book->update($request->all());
        return redirect()->route('books.index')->with('success', 'Buku berhasil diperbarui!');
    }

    public function destroy(Book $book)
    {
        $book->delete(); // Hapus data buku dari sistem
        return redirect()->route('books.index')->with('success', 'Buku berhasil dihapus!');
    }
}